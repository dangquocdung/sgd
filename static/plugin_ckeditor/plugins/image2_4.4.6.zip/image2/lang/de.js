﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'de', {
	alt: 'Alternativer Text',
	btnUpload: 'Zum Server senden',
	captioned: 'Bild mit Überschrift',
	captionPlaceholder: 'Überschrift',
	infoTab: 'Bild-Info',
	lockRatio: 'Größenverhältnis beibehalten',
	menu: 'Bild-Eigenschaften',
	pathName: 'Bild',
	pathNameCaption: 'Überschrift',
	resetSize: 'Größe zurücksetzen',
	resizer: 'Zum vergrößern anwählen und ziehen',
	title: 'Bild-Eigenschaften',
	uploadTab: 'Hochladen',
	urlMissing: 'Imagequelle URL fehlt.'
} );
